<p align="center"><img src="https://menu.munshijji.tech/assets/img/logos/logo.png" width="150"></p>

<p align="center">
<a href="#"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<!--<a href="#"><img src="https://poser.pugx.org/laravel/framework/d/total.svg" alt="Total Bills"></a>-->
<a href="#"><img src="https://poser.pugx.org/laravel/framework/v/stable.svg" alt="Latest Stable Version"></a>
<a href="#"><img src="https://poser.pugx.org/laravel/framework/license.svg" alt="License"></a>
</p>

## Buffet Box  

# online menu and cloud kitchen 
Most Advance online restaurant menu, online restaurant menu, free online restaurant menu, free online restaurant menu app, online restaurant menu service provider

## Demo Link ( Open With Phone ) : <a href="https://munshijji.tech/menu" target="_blank">menu.munshijji.tech</a> <br><br>

- Most Advance online restaurant menu, 
- online restaurant menu, 
- free online restaurant menu, 
- free online restaurant menu app, 
- online restaurant menu service provider


# online menu and cloud kitchen
Most Advanced POS Billing & Invoicing Software which can perfectly fit on your WholeSale &amp; Retail Business

<a href="https://munshijji.tech/menu" target="_blank"><img src="https://github.com/munshiji/online-menu-and-cloud-kitchen/blob/main/1.jpeg?raw=true"  alt="Online Menu"></a> 

<br><br>
## Demo Link ( Open With Phone ) : <a href="https://munshijji.tech/menu" target="_blank">menu.munshijji.tech</a> <br><br>


## Price : 292 USD / Year ( world wide )
## Price : 15000 Rs / Year ( India )


## Contact Us :- 

WhatsApp :- <a href="https://web.whatsapp.com/send?phone=917798383112" target="_blank" >+91-7798383112</a>
<br>
Email :- <a href="mailto:munshiji.zakir@gmail.com" target="_blank" >munshiji.zakir@gmail.com</a> 
